﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Caching;
using System.Web.Http;
using UsersAPP.Models.User;

namespace UsersAPP.Controllers
{
    public class UsersController : ApiController
    {
        public List<UserModel> Get()
        {
            return Users.GetUsersCache();
        }

        public UserModel Get(int id)
        {
            return Users.GetUsersCache().Where(u => u.Id == id).FirstOrDefault();
        }

        public void Post(UserModel user)
        {
            user.Id = Users.GetUsersCache().Count > 0 ? Users.GetUsersCache().Last().Id + 1 : 1;
            Users.AddUsersCache(user);
        }

        public void Put(int id, UserModel user)
        {
            var userOld = Users.GetUsersCache().Where(u => u.Id == id).FirstOrDefault();

            userOld.Name = user.Name;
            userOld.Age = user.Age;
            userOld.Address = user.Address;
        }

        public void Delete(int id)
        {
            var user = Users.GetUsersCache().Where(u => u.Id == id).FirstOrDefault();
            Users.GetUsersCache().Remove(user);
        }
    }

    public static class Users
    {
        private static List<UserModel> usersList = new List<UserModel>();
        static Users()
        {
            var cacheKey = "usersList";
            MemoryCache.Default.Remove(cacheKey);
            ObjectCache cache = MemoryCache.Default;
            CacheItemPolicy policy = new CacheItemPolicy();
            cache.Add(cacheKey, usersList, policy);
        }

        public static void AddUsersCache(UserModel userModel)
        {
            var users = GetUsersCache();
            users.Add(userModel);
        }

        public static List<UserModel> GetUsersCache()
        {
            var cache = MemoryCache.Default.GetCacheItem("usersList");
            return (List<UserModel>)cache.Value;
        }
    }
}
