﻿(function (app) {
    var userDetail = function ($scope, $routeParams, userService) {
        var id = $routeParams.id;
        userService
            .getUserById(id)
            .then(function (response) {
                $scope.user = response.data;
            }, function (error) {
                console.log(error);
            });

        $scope.createEdit = function () {
            $scope.createEdit.user = angular.copy($scope.user);
        };
    };

    app.controller("userDetail", userDetail)

}(angular.module("users")));