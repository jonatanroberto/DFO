﻿(function (app) {
    var listController = function ($scope, userService) {
        userService
            .getUsers()
            .then(function (response) {
                $scope.users = response.data;
            }, function (error) {
                console.log(error);
            });

        $scope.deleteUser = function (user) {
            userService.deleteUser(user)
                .then(function () {
                    removeUserById(user.Id)
                }, function (error) {
                    console.log(error);
                });
        };

        $scope.createUser = function () {
            $scope.createEdit = {
                user: {
                    Id: 0,
                    Name: "",
                    Age: 0,
                    Address: ""
                }
            };

            $scope.user = angular.copy($scope.createEdit.user);
        };

        var removeUserById = function (id) {
            for (var i = 0; i < $scope.users.length; i++) {
                if ($scope.users[i].Id == id) {
                    $scope.users.splice(i, 1);
                    break;
                }
            }
        };
    };

    app.controller("listController", listController)

}(angular.module("users")));