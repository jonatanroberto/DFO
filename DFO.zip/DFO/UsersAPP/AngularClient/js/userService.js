﻿(function (app) {
    var userService = function ($http, userApiUrl) {

        var getUsers = function () {
            return $http.get(userApiUrl);
        };
        var getUserById = function (id) {
            return $http.get(userApiUrl + id);
        };
        var updateUser = function (user) {
            return $http.put(userApiUrl + user.Id, user);
        };
        var createUser = function (user) {
            return $http.post(userApiUrl, user);
        };
        var deleteUser = function (user) {
            return $http.delete(userApiUrl + user.Id);
        };
        return {
            getUsers: getUsers,
            getUserById: getUserById,
            updateUser: updateUser,
            createUser: createUser,
            deleteUser: deleteUser
        };
    };
    app.factory("userService", userService);
}(angular.module("users")))