﻿(function (app) {
    var createUpdateUserController = function ($scope, userService) {

        $scope.isUpdate = function () {
            return $scope.createEdit && $scope.createEdit.user;
        };
        $scope.cancel = function () {
            $scope.createEdit.user = null;
        };
        $scope.createEditUser = function () {
            if ($scope.user.Id) {
                updateUser();
            } else {
                createUser();
            }
        };
        var updateUser = function () {
            userService.updateUser($scope.createEdit.user)
                .then(function () {
                    angular.extend($scope.user, $scope.createEdit.user);
                    $scope.createEdit.user = null;
                }, function (error) {
                    console.log(error);
                });
        };
        var createUser = function () {
            userService.createUser($scope.createEdit.user)
                .then(function () {
                    window.location.href = "#/";
                }, function (error) {
                    console.log(error);
                });
        };
    };
    app.controller("createUpdateUserController", createUpdateUserController);
}(angular.module("users")));