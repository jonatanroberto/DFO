﻿(function () {
    var app = angular.module('users', ["ngRoute"]);

    var config = function ($routeProvider) {
        $routeProvider
            .when("/",
                { templateUrl: "users/listusers.html", controller: "listController" })
            .when("/UserById/:id",
                { templateUrl: "users/userbyid.html", controller: "userDetail" })
            .otherwise(
                { redirecTo: "/" });
    };
    app.config(config);
    app.constant("userApiUrl", "/api/users/");

    app.run([
        '$rootScope',
        function ($rootScope) {
            // see what's going on when the route tries to change
            $rootScope.$on('$locationChangeStart', function (event, newUrl, oldUrl) {
                // both newUrl and oldUrl are strings
                console.log('Starting to leave %s to go to %s', oldUrl, newUrl);
            });
        }
    ]);

    app.run(function ($rootScope) {
        $rootScope.$on('$routeChangeSuccess', function (e, current, pre) {
            var fullRoute = current.$$route.originalPath,
                routeParams = current.params,
                resolvedRoute;

            console.log(fullRoute);
            console.log(routeParams);

            resolvedRoute = fullRoute.replace(/:id/, routeParams.id);
            console.log(resolvedRoute);
        });
    });
}());